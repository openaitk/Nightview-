/**
 * Stellarium 3D & Universe Explorer — Production Backend API & Static Server
 * Features:
 *  1. Serves the single-file Stellarium 3D frontend (index.html) with gzip/cache headers
 *  2. Secure AI Proxy (/api/ai/chat) for apikeys.in / Gemini / OpenAI so API keys stay secret on the server
 *  3. Server-side Ephemeris & Rise/Transit/Set API (/api/astronomy/ephemeris)
 *  4. Health check endpoint (/api/health) for Render / Railway / Cloud Run / Docker
 */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  getJulianDate,
  getLSTDegrees,
  raDecToAltAz,
  computeRiseTransitSet,
  computeSolarSystemEphemeris,
  calculateTelescopeOptics
} from './src/engines/AstronomyEngine.mjs';
import { EXOPLANET_CATALOG, METEOR_SHOWERS_CATALOG, BLACK_HOLE_CATALOG } from './src/catalogues/ScientificCatalogues.mjs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || 8080;
const API_PROVIDER = process.env.AI_PROVIDER || 'apikeys_in'; // 'apikeys_in' | 'gemini' | 'openai'
const API_KEY = process.env.APIKEYS_IN_KEY || process.env.GEMINI_API_KEY || process.env.OPENAI_API_KEY || '';
const API_MODEL = process.env.AI_MODEL || 'gpt-4o-mini';
const API_ENDPOINT = process.env.AI_ENDPOINT || 'https://api.apikeys.in/v1/chat/completions';

function sendJSON(res, status, payload) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(payload));
}

function parseBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > 1e6) req.destroy();
    });
    req.on('end', () => {
      try {
        resolve(raw ? JSON.parse(raw) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on('error', reject);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);

  if (req.method === 'OPTIONS') {
    return sendJSON(res, 200, { ok: true });
  }

  // 1. Health Check
  if (url.pathname === '/api/health') {
    return sendJSON(res, 200, {
      status: 'ok',
      service: 'stellarium-3d-backend',
      timestamp: new Date().toISOString(),
      aiConfigured: Boolean(API_KEY)
    });
  }

  // 2. Live Astronomical Ephemeris Endpoint: GET /api/astronomy/ephemeris?lat=16.705&lon=74.243
  if (url.pathname === '/api/astronomy/ephemeris' && req.method === 'GET') {
    const lat = parseFloat(url.searchParams.get('lat') ?? '16.7050');
    const lon = parseFloat(url.searchParams.get('lon') ?? '74.2433');
    const timeMs = parseInt(url.searchParams.get('time') ?? String(Date.now()), 10);

    const jd = getJulianDate(timeMs);
    const lstDeg = getLSTDegrees(timeMs, lon);
    const ephemeris = computeSolarSystemEphemeris(timeMs);

    const bodies = {};
    for (const [name, data] of Object.entries(ephemeris)) {
      if (data.ra !== undefined && data.dec !== undefined) {
        const horiz = raDecToAltAz(data.ra, data.dec, lstDeg, lat, true);
        const rts = computeRiseTransitSet(data.ra, data.dec, lat, lon, timeMs);
        bodies[name] = { ...data, ...horiz, rts };
      } else {
        bodies[name] = data;
      }
    }

    return sendJSON(res, 200, {
      epoch: 'J2000.0 (ICRS)',
      observer: { lat, lon },
      julianDate: jd,
      lstDegrees: lstDeg,
      bodies
    });
  }

  // 3. Catalogues Endpoint: GET /api/catalogues
  if (url.pathname === '/api/catalogues' && req.method === 'GET') {
    return sendJSON(res, 200, {
      exoplanets: EXOPLANET_CATALOG,
      meteorShowers: METEOR_SHOWERS_CATALOG,
      blackHoles: BLACK_HOLE_CATALOG
    });
  }

  // 4. Secure Server-Side AI Proxy: POST /api/ai/chat
  if (url.pathname === '/api/ai/chat' && req.method === 'POST') {
    try {
      const body = await parseBody(req);
      const { query, telemetry, clientApiKey, provider } = body;
      const activeKey = clientApiKey || API_KEY;
      const activeProvider = provider || API_PROVIDER;

      if (!activeKey) {
        return sendJSON(res, 400, {
          error: 'No API key configured on server. Set APIKEYS_IN_KEY or GEMINI_API_KEY in environment variables.'
        });
      }

      const sysPrompt = `You are the Stellarium 3D AI Sky Copilot. Answer concisely (2-4 sentences) using HTML <b> tags for key figures. Ground all facts strictly in this live observer telemetry: ${telemetry || 'Standard J2000 sky'}`;

      if (activeProvider === 'gemini') {
        const gUrl = `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(API_MODEL)}:generateContent?key=${encodeURIComponent(activeKey)}`;
        const gRes = await fetch(gUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [{ parts: [{ text: `${sysPrompt}\n\nUser Question: ${query}` }] }]
          })
        });
        const gData = await gRes.json();
        const reply = gData?.candidates?.[0]?.content?.parts?.[0]?.text || 'Unable to generate response.';
        return sendJSON(res, 200, { provider: 'gemini', reply });
      } else {
        const rRes = await fetch(API_ENDPOINT, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${activeKey}`,
            'x-api-key': activeKey
          },
          body: JSON.stringify({
            model: API_MODEL,
            messages: [
              { role: 'system', content: sysPrompt },
              { role: 'user', content: query }
            ],
            temperature: 0.4,
            max_tokens: 280
          })
        });
        const rData = await rRes.json();
        const reply = rData?.choices?.[0]?.message?.content || 'Unable to generate response.';
        return sendJSON(res, 200, { provider: activeProvider, reply });
      }
    } catch (err) {
      return sendJSON(res, 500, { error: 'AI proxy request failed', details: String(err.message || err) });
    }
  }

  // 5. Serve Frontend Application (index.html)
  if (url.pathname === '/' || url.pathname === '/index.html') {
    const htmlPath = path.join(__dirname, 'public', 'index.html');
    if (fs.existsSync(htmlPath)) {
      res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
      return fs.createReadStream(htmlPath).pipe(res);
    }
  }

  sendJSON(res, 404, { error: 'Not Found' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Stellarium 3D Backend & Web Server listening on http://0.0.0.0:${PORT}`);
});
