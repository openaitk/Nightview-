import assert from 'node:assert/strict';
import {
  getJulianDate,
  getLSTDegrees,
  raDecToAltAz,
  computeRiseTransitSet,
  computeSolarSystemEphemeris,
  calculateTelescopeOptics,
  getAtmosphericRefractionDeg
} from '../src/engines/AstronomyEngine.mjs';

console.log('Running Stellarium 3D Astronomy Engine Unit & Regression Tests...');

// Test 1: J2000.0 Epoch Julian Date (2000-01-01T12:00:00Z = JD 2451545.0)
const j2000Ms = Date.UTC(2000, 0, 1, 12, 0, 0);
const jd = getJulianDate(j2000Ms);
assert(Math.abs(jd - 2451545.0) < 1e-6, `Expected JD 2451545.0, got ${jd}`);
console.log('✓ Test 1 Passed: J2000.0 Julian Date exact match (2451545.0)');

// Test 2: GMST at J2000.0 Epoch (0° Longitude should be ~280.4606°)
const gmst = getLSTDegrees(j2000Ms, 0.0);
assert(Math.abs(gmst - 280.4606) < 0.01, `Expected GMST ~280.4606°, got ${gmst}`);
console.log(`✓ Test 2 Passed: GMST at J2000.0 verified (${gmst.toFixed(4)}°)`);

// Test 3: Celestial Pole Altitude equals Observer Latitude
const polarisAltAz = raDecToAltAz(0, 90.0, 120.0, 16.7050, false);
assert(Math.abs(polarisAltAz.alt - 16.7050) < 1e-4, `North Celestial Pole altitude should equal latitude 16.7050°, got ${polarisAltAz.alt}`);
console.log(`✓ Test 3 Passed: North Celestial Pole altitude matches Kolhapur latitude (${polarisAltAz.alt.toFixed(4)}°)`);

// Test 4: Bennett Atmospheric Refraction at Horizon (~0.5° / 34 arcmin) vs Zenith (~0°)
const refHorizon = getAtmosphericRefractionDeg(0.0);
const refZenith = getAtmosphericRefractionDeg(89.9);
assert(refHorizon > 0.45 && refHorizon < 0.65, `Horizon refraction out of bounds: ${refHorizon}`);
assert(refZenith < 0.01, `Zenith refraction should be near zero: ${refZenith}`);
console.log(`✓ Test 4 Passed: Atmospheric refraction verified (Horizon: ${(refHorizon*60).toFixed(1)}', Zenith: ${(refZenith*60).toFixed(2)}')`);

// Test 5: Rise / Transit / Set Circumpolar vs Rising/Setting
const rtsM31 = computeRiseTransitSet(0.712, 41.269, 16.7050, 74.2433, Date.now());
assert(rtsM31.status === 'Rises & Sets', `M31 at 16.7°N should rise and set, got ${rtsM31.status}`);
const rtsPolaris = computeRiseTransitSet(2.530, 89.264, 16.7050, 74.2433, Date.now());
assert(rtsPolaris.status.includes('Circumpolar'), `Polaris at 16.7°N should be circumpolar`);
console.log(`✓ Test 5 Passed: Rise/Transit/Set solver verified (M31 Rise ${rtsM31.rise}, Transit ${rtsM31.transit}, Set ${rtsM31.set})`);

// Test 6: Solar System Keplerian Ephemeris Validation
const eph = computeSolarSystemEphemeris(Date.UTC(2026, 10, 1, 0, 0, 0));
assert(eph.Sun.ra >= 0 && eph.Sun.ra <= 24, 'Sun RA valid');
assert(eph.Jupiter.distAU > 3.8 && eph.Jupiter.distAU < 6.5, `Jupiter distance realistic: ${eph.Jupiter.distAU} AU`);
assert(eph.Saturn.distAU > 8.0 && eph.Saturn.distAU < 11.2, `Saturn distance realistic: ${eph.Saturn.distAU} AU`);
console.log(`✓ Test 6 Passed: Keplerian Ephemeris verified (Jupiter: ${eph.Jupiter.distText}, Saturn: ${eph.Saturn.distText}, Moon Phase: ${eph.Moon.phasePct}%)`);

// Test 7: Optical Telescope Calculator
const optics = calculateTelescopeOptics({ apertureMm: 200, focalLengthMm: 1000, eyepieceMm: 10, eyepieceAfovDeg: 82 });
assert.equal(optics.magnification, 100);
assert.equal(optics.focalRatio, '5.0');
assert.equal(optics.exitPupilMm, '2.00');
assert.equal(optics.dawesLimitArcsec, '0.58');
console.log(`✓ Test 7 Passed: Optical Telescope Calculator verified (${optics.magnification}x, f/${optics.focalRatio}, Dawes ${optics.dawesLimitArcsec}")`);

console.log('ALL 7 ASTRONOMICAL & OPTICAL UNIT TESTS PASSED.');
