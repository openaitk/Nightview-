/**
 * Grounded AI Astronomy Assistant Engine
 * Answers user astronomy queries strictly using live computed ephemeris, observer horizon state, and catalog provenance.
 */
import { raDecToAltAz, computeRiseTransitSet, formatRA, formatDec } from './AstronomyEngine.mjs';

export function generateGroundedAstronomyResponse(query, context) {
  const { lat, lon, locationName, lstDeg, simTime, selectedObject, visibleDSOs, solarSystem, optics, bortleClass } = context;
  const q = query.toLowerCase();

  if (q.includes('where am i looking') || q.includes('current view')) {
    return `You are observing from **${locationName}** (${lat.toFixed(2)}°N, ${lon.toFixed(2)}°E) under **Bortle Class ${bortleClass}** skies. Your camera is pointed toward Azimuth **${context.camAz.toFixed(1)}°**, Altitude **${context.camAlt.toFixed(1)}°** (FOV **${context.fov.toFixed(1)}°**), and the Local Sidereal Time is **${(lstDeg / 15).toFixed(2)}h**.`;
  }

  if (q.includes('observe tonight') || q.includes('best objects') || q.includes('visible')) {
    const topDSOs = visibleDSOs.slice(0, 5).map(d => `${d.id} (${d.Alt.toFixed(0)}° Alt)`).join(', ');
    return `Right now from **${locationName}**, **${visibleDSOs.length} cataloged Deep-Sky Objects** are above your local horizon. Best high-altitude targets include: **${topDSOs || 'M31, M42, M45'}**. The Moon is at **${solarSystem.Moon.phasePct}% illumination** (${solarSystem.Moon.distText}).`;
  }

  if (q.includes('telescope') || q.includes('eyepiece') || q.includes('magnification')) {
    return `With your configured **${optics.apertureMm}mm f/${optics.focalRatio}** telescope and **${optics.eyepieceMm}mm** eyepiece, you achieve **${optics.magnification}x magnification**, a **${optics.trueFovDeg}° (${optics.trueFovArcmin}')** True Field of View, an exit pupil of **${optics.exitPupilMm}mm**, a Dawes resolution limit of **${optics.dawesLimitArcsec}"**, and a visual limiting magnitude of **+${optics.limitingMag} mag** under Bortle ${bortleClass} skies.`;
  }

  if (selectedObject) {
    const { alt, az } = raDecToAltAz(selectedObject.ra, selectedObject.dec, lstDeg, lat, true);
    const rts = computeRiseTransitSet(selectedObject.ra, selectedObject.dec, lat, lon, simTime);
    return `**${selectedObject.name}** (${selectedObject.typeLabel}) is located at J2000 coordinates **RA ${selectedObject.ra.toFixed(3)}h, Dec ${selectedObject.dec.toFixed(2)}°** at a measured distance of **${selectedObject.dist || '—'}** (Magnitude **${selectedObject.mag}**). From ${locationName}, its current horizontal position is **Azimuth ${az.toFixed(1)}°, Altitude ${alt.toFixed(1)}°** (Rise: ${rts.rise}, Transit: ${rts.transit}, Set: ${rts.set}). **Provenance:** ${selectedObject.provenance || 'Hipparcos / Gaia DR3 / STScI'} (${selectedObject.epistemicBadge || 'Measured ICRS Position'}). ${selectedObject.desc || ''}`;
  }

  return `Ask me about any selected celestial object, tonight's best observable targets, rise/transit/set times, planetary ephemerides, or optical telescope parameters.`;
}
