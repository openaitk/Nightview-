/**
 * Validated Astronomical Calculation Engine
 * Reference Epoch: J2000.0 (JD 2451545.0, ICRS)
 * Formulas based on Jean Meeus "Astronomical Algorithms" & JPL Low-Precision Planetary Ephemerides
 */

export const DEG2RAD = Math.PI / 180;
export const RAD2DEG = 180 / Math.PI;
export const J2000_JD = 2451545.0;

export function getJulianDate(timestampMs) {
  return timestampMs / 86400000 + 2440587.5;
}

export function getDaysSinceJ2000(timestampMs) {
  return getJulianDate(timestampMs) - J2000_JD;
}

export function normalizeDegrees(deg) {
  let d = deg % 360;
  return d < 0 ? d + 360 : d;
}

export function getLSTDegrees(timestampMs, lonDeg) {
  const jd = getJulianDate(timestampMs);
  const T = (jd - J2000_JD) / 36525.0;
  let gmst = 280.46061837 + 360.98564736629 * (jd - J2000_JD) + 0.000387933 * T * T - (T * T * T) / 38710000.0;
  return normalizeDegrees(gmst + lonDeg);
}

/**
 * Bennett's empirical atmospheric refraction formula (in degrees)
 * Valid for true altitude hDeg > -1°
 */
export function getAtmosphericRefractionDeg(trueAltDeg, pressureMbar = 1010, tempC = 15) {
  if (trueAltDeg < -1.5) return 0;
  const h = Math.max(-1.0, trueAltDeg);
  const R_arcmin = (1.0 / Math.tan((h + 7.31 / (h + 4.4)) * DEG2RAD)) * (pressureMbar / 1010.0) * (283.0 / (273.0 + tempC));
  return Math.max(0, R_arcmin / 60.0);
}

export function raDecToAltAz(raHours, decDeg, lstDeg, latDeg, applyRefraction = false) {
  const raDeg = raHours * 15.0;
  const ha = normalizeDegrees(lstDeg - raDeg);
  const haRad = ha * DEG2RAD;
  const decRad = decDeg * DEG2RAD;
  const latRad = latDeg * DEG2RAD;

  const sinAlt = Math.sin(decRad) * Math.sin(latRad) + Math.cos(decRad) * Math.cos(latRad) * Math.cos(haRad);
  const trueAltDeg = Math.asin(Math.max(-1, Math.min(1, sinAlt))) * RAD2DEG;
  const altDeg = applyRefraction ? trueAltDeg + getAtmosphericRefractionDeg(trueAltDeg) : trueAltDeg;

  const cosAlt = Math.cos(trueAltDeg * DEG2RAD);
  let azDeg = 0;
  if (Math.abs(cosAlt) > 1e-7 && Math.abs(Math.cos(latRad)) > 1e-7) {
    const cosAz = (Math.sin(decRad) - Math.sin(trueAltDeg * DEG2RAD) * Math.sin(latRad)) / (cosAlt * Math.cos(latRad));
    azDeg = Math.acos(Math.max(-1, Math.min(1, cosAz))) * RAD2DEG;
    if (Math.sin(haRad) > 0) azDeg = 360.0 - azDeg;
  }
  return { alt: altDeg, trueAlt: trueAltDeg, az: azDeg, haHours: ha / 15.0 };
}

/**
 * Computes Rise, Transit, and Set local solar times (HH:MM) for an object on the date of timestampMs
 */
export function computeRiseTransitSet(raHours, decDeg, latDeg, lonDeg, timestampMs, horizonAltDeg = -0.5667) {
  const dt = new Date(timestampMs);
  const localMidnight = new Date(dt.getFullYear(), dt.getMonth(), dt.getDate(), 0, 0, 0).getTime();
  const lst0 = getLSTDegrees(localMidnight, lonDeg) / 15.0; // hours
  let transitHours = (raHours - lst0) % 24;
  if (transitHours < 0) transitHours += 24;
  // Sidereal to solar rate factor
  transitHours *= 0.997269566;

  const latRad = latDeg * DEG2RAD;
  const decRad = decDeg * DEG2RAD;
  const h0Rad = horizonAltDeg * DEG2RAD;

  const cosH0 = (Math.sin(h0Rad) - Math.sin(latRad) * Math.sin(decRad)) / (Math.cos(latRad) * Math.cos(decRad));

  const fmt = (h) => {
    const norm = ((h % 24) + 24) % 24;
    const hh = Math.floor(norm);
    const mm = Math.floor((norm - hh) * 60);
    return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
  };

  const maxAlt = 90.0 - Math.abs(latDeg - decDeg);

  if (cosH0 < -1) {
    return { status: 'Circumpolar (Never Sets)', rise: 'Circumpolar', transit: fmt(transitHours), set: 'Circumpolar', maxAlt };
  }
  if (cosH0 > 1) {
    return { status: 'Never Rises', rise: 'Never', transit: fmt(transitHours), set: 'Never', maxAlt };
  }

  const H0Hours = (Math.acos(cosH0) * RAD2DEG) / 15.0 * 0.997269566;
  const riseHours = transitHours - H0Hours;
  const setHours = transitHours + H0Hours;

  return {
    status: 'Rises & Sets',
    rise: fmt(riseHours),
    transit: fmt(transitHours),
    set: fmt(setHours),
    maxAlt
  };
}

/**
 * Low-Precision Keplerian Planetary & Lunar Ephemeris (J2000.0)
 * Computes heliocentric 3D coordinates (x, y, z in AU) and geocentric RA/Dec, distance, and elongation
 */
const ORBITAL_ELEMENTS = {
  Mercury: { a: 0.387098, e: 0.205630, i: 7.0049, L0: 252.2508, n: 4.09233445, wBar: 77.4564, node: 48.3316 },
  Venus:   { a: 0.723332, e: 0.006773, i: 3.3947, L0: 181.9798, n: 1.60213034, wBar: 131.5637, node: 76.6807 },
  Earth:   { a: 1.000000, e: 0.016709, i: 0.0000, L0: 100.4644, n: 0.98560767, wBar: 102.9472, node: 0.0 },
  Mars:    { a: 1.523679, e: 0.093401, i: 1.8497, L0: 355.4533, n: 0.52403840, wBar: 336.0602, node: 49.5574 },
  Jupiter: { a: 5.202603, e: 0.048498, i: 1.3033, L0: 34.3515,  n: 0.08308529, wBar: 14.3312,  node: 100.4644 },
  Saturn:  { a: 9.554909, e: 0.055546, i: 2.4889, L0: 50.0774,  n: 0.03345965, wBar: 93.0572,  node: 113.6655 }
};

export function solveKepler(M_rad, e) {
  let E = M_rad;
  for (let iter = 0; iter < 6; iter++) {
    E = E - (E - e * Math.sin(E) - M_rad) / (1 - e * Math.cos(E));
  }
  return E;
}

export function getHeliocentricXYZ(planetKey, d) {
  const el = ORBITAL_ELEMENTS[planetKey];
  const L = normalizeDegrees(el.L0 + el.n * d);
  const M = normalizeDegrees(L - el.wBar) * DEG2RAD;
  const E = solveKepler(M, el.e);

  const xv = el.a * (Math.cos(E) - el.e);
  const yv = el.a * Math.sqrt(1 - el.e * el.e) * Math.sin(E);
  const v = Math.atan2(yv, xv);
  const r = Math.hypot(xv, yv);

  const w = (el.wBar - el.node) * DEG2RAD;
  const nodeRad = el.node * DEG2RAD;
  const iRad = el.i * DEG2RAD;

  const u = v + w;
  const x = r * (Math.cos(nodeRad) * Math.cos(u) - Math.sin(nodeRad) * Math.sin(u) * Math.cos(iRad));
  const y = r * (Math.sin(nodeRad) * Math.cos(u) + Math.cos(nodeRad) * Math.sin(u) * Math.cos(iRad));
  const z = r * (Math.sin(u) * Math.sin(iRad));
  return { x, y, z, r };
}

export function computeSolarSystemEphemeris(timestampMs) {
  const d = getDaysSinceJ2000(timestampMs);
  const eps = (23.439291 - 0.0000137 * d) * DEG2RAD; // Obliquity of the ecliptic
  const earth = getHeliocentricXYZ('Earth', d);

  const results = {};

  // 1. Sun Geocentric Position
  const sunX = -earth.x;
  const sunY = -earth.y;
  const sunZ = -earth.z;
  const sunEqY = sunY * Math.cos(eps) - sunZ * Math.sin(eps);
  const sunEqZ = sunY * Math.sin(eps) + sunZ * Math.cos(eps);
  const sunDistAU = Math.hypot(sunX, sunEqY, sunEqZ);
  const sunRA = (normalizeDegrees(Math.atan2(sunEqY, sunX) * RAD2DEG)) / 15.0;
  const sunDec = Math.asin(sunEqZ / sunDistAU) * RAD2DEG;
  const sunLon = normalizeDegrees(Math.atan2(sunY, sunX) * RAD2DEG);

  results.Sun = {
    ra: sunRA, dec: sunDec, distAU: sunDistAU, distText: `${sunDistAU.toFixed(3)} AU`,
    helio: { x: 0, y: 0, z: 0 }, mag: -26.74, phasePct: 100
  };
  results.Earth = { helio: earth };

  // 2. Moon Geocentric Position & Phase
  const L_m = normalizeDegrees(218.316 + 13.176396 * d);
  const M_m = normalizeDegrees(134.963 + 13.064993 * d) * DEG2RAD;
  const F_m = normalizeDegrees(93.272 + 13.229350 * d) * DEG2RAD;
  const moonLon = normalizeDegrees(L_m + 6.289 * Math.sin(M_m)) * DEG2RAD;
  const moonLat = (5.128 * Math.sin(F_m)) * DEG2RAD;
  const moonDistKm = 385001 - 20905 * Math.cos(M_m);

  const mx = Math.cos(moonLat) * Math.cos(moonLon);
  const my = Math.cos(moonLat) * Math.sin(moonLon);
  const mz = Math.sin(moonLat);
  const mEqY = my * Math.cos(eps) - mz * Math.sin(eps);
  const mEqZ = my * Math.sin(eps) + mz * Math.cos(eps);
  const moonRA = normalizeDegrees(Math.atan2(mEqY, mx) * RAD2DEG) / 15.0;
  const moonDec = Math.asin(mEqZ) * RAD2DEG;

  const elongDeg = normalizeDegrees(moonLon * RAD2DEG - sunLon);
  const moonPhasePct = Math.round(((1 - Math.cos(elongDeg * DEG2RAD)) / 2) * 100);

  results.Moon = {
    ra: moonRA, dec: moonDec, distKm: Math.round(moonDistKm),
    distText: `${Math.round(moonDistKm).toLocaleString()} km`,
    phasePct: moonPhasePct, mag: -12.4
  };

  // 3. Planets
  ['Mercury', 'Venus', 'Mars', 'Jupiter', 'Saturn'].forEach(pKey => {
    const helio = getHeliocentricXYZ(pKey, d);
    const gx = helio.x - earth.x;
    const gy = helio.y - earth.y;
    const gz = helio.z - earth.z;

    const eqY = gy * Math.cos(eps) - gz * Math.sin(eps);
    const eqZ = gy * Math.sin(eps) + gz * Math.cos(eps);
    const distAU = Math.hypot(gx, eqY, eqZ);
    const ra = normalizeDegrees(Math.atan2(eqY, gx) * RAD2DEG) / 15.0;
    const dec = Math.asin(eqZ / distAU) * RAD2DEG;

    results[pKey] = {
      ra, dec, distAU, distText: `${distAU.toFixed(2)} AU`,
      helio
    };
  });

  return results;
}

/**
 * Optical Telescope & Astrophotography Sensor Calculator
 */
export function calculateTelescopeOptics({
  apertureMm = 200,
  focalLengthMm = 1200,
  eyepieceMm = 14,
  eyepieceAfovDeg = 82,
  barlowFactor = 1.0,
  sensorWidthMm = 23.5,
  sensorHeightMm = 15.6,
  bortleClass = 4
}) {
  const effectiveFocalMm = focalLengthMm * barlowFactor;
  const focalRatio = effectiveFocalMm / apertureMm;
  const magnification = effectiveFocalMm / eyepieceMm;
  const exitPupilMm = apertureMm / magnification;
  const trueFovDeg = eyepieceAfovDeg / magnification;
  const dawesLimitArcsec = 116.0 / apertureMm;
  const rayleighLimitArcsec = 138.0 / apertureMm;
  // Limiting visual magnitude adjusted for Bortle light pollution (Bortle 1 = +0.4 boost, Bortle 9 = -2.2 penalty)
  const bortlePenalty = (bortleClass - 3) * 0.35;
  const limitingMag = 2.7 + 5.0 * Math.log10(apertureMm) - bortlePenalty;

  const sensorFovWidthDeg = (2 * Math.atan(sensorWidthMm / (2 * effectiveFocalMm))) * RAD2DEG;
  const sensorFovHeightDeg = (2 * Math.atan(sensorHeightMm / (2 * effectiveFocalMm))) * RAD2DEG;

  return {
    effectiveFocalMm: Math.round(effectiveFocalMm),
    focalRatio: focalRatio.toFixed(1),
    magnification: Math.round(magnification),
    exitPupilMm: exitPupilMm.toFixed(2),
    trueFovDeg: trueFovDeg.toFixed(2),
     trueFovArcmin: (trueFovDeg * 60).toFixed(1),
    dawesLimitArcsec: dawesLimitArcsec.toFixed(2),
    rayleighLimitArcsec: rayleighLimitArcsec.toFixed(2),
    limitingMag: limitingMag.toFixed(1),
    sensorFovDeg: `${sensorFovWidthDeg.toFixed(2)}° × ${sensorFovHeightDeg.toFixed(2)}°`
  };
}
