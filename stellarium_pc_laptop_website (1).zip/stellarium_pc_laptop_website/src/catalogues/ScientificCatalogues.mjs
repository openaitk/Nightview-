/**
 * Validated Open Astronomical Catalogues with Data Provenance, Epoch, and Uncertainty Metadata
 * Sources: Hipparcos / Gaia DR3 (ESA), SIMBAD (CDS), Messier/NGC (STScI/NASA), NASA Exoplanet Archive, IMO
 */

export const EXOPLANET_CATALOG = [
  {
    id: 'TRAPPIST-1', name: 'TRAPPIST-1 System (7 Earth-Sized Planets)',
    subtitle: 'Ultra-Cool Red Dwarf M8V • Aquarius',
    category: 'exoplanet', typeLabel: 'Multi-Planet Exoplanet System',
    ra: 23.108, dec: -5.041, mag: 18.8, dist: '40.66 ± 0.04 ly', size: '0.12 AU System',
    color: '#fb7185', accent: '#38bdf8',
    epoch: 'J2000.0 (ICRS)', provenance: 'NASA Exoplanet Archive / Gaia DR3 / Spitzer & JWST',
    epistemicBadge: 'Measured Transit & TTV Orbits + Artistic Surface Render',
    planets: [
      { name: 'b', aAU: 0.0115, periodDays: 1.51, radiusEarth: 1.116, hz: false, col: '#f97316' },
      { name: 'c', aAU: 0.0158, periodDays: 2.42, radiusEarth: 1.097, hz: false, col: '#fbbf24' },
      { name: 'd', aAU: 0.0223, periodDays: 4.05, radiusEarth: 0.788, hz: true,  col: '#38bdf8' },
      { name: 'e', aAU: 0.0293, periodDays: 6.10, radiusEarth: 0.920, hz: true,  col: '#10b981' },
      { name: 'f', aAU: 0.0385, periodDays: 9.21, radiusEarth: 1.045, hz: true,  col: '#06b6d4' },
      { name: 'g', aAU: 0.0469, periodDays: 12.35, radiusEarth: 1.129, hz: true, col: '#60a5fa' },
      { name: 'h', aAU: 0.0619, periodDays: 18.77, radiusEarth: 0.755, hz: false, col: '#a855f7' }
    ],
    desc: 'Resonant chain of seven temperate terrestrial planets orbiting an ultra-cool M8V dwarf star, with planets d, e, f, and g inside the circumstellar habitable zone.'
  },
  {
    id: 'ProximaCen', name: 'Proxima Centauri (α Cen C)',
    subtitle: 'Nearest Exoplanet Host Star • Centaurus',
    category: 'exoplanet', typeLabel: 'Red Dwarf + Habitable Zone Exoplanet',
    ra: 14.495, dec: -62.679, mag: 11.13, dist: '4.2465 ± 0.0003 ly', size: '0.0485 AU Orbit',
    color: '#ef4444', accent: '#34d399',
    epoch: 'J2000.0 (ICRS)', provenance: 'ESO HARPS / ESPRESSO Radial Velocity + Gaia DR3',
    epistemicBadge: 'Measured RV Orbit (m sin i) + Artistic Planet Visualization',
    planets: [
      { name: 'd', aAU: 0.0288, periodDays: 5.12, radiusEarth: 0.81, hz: false, col: '#f59e0b' },
      { name: 'b', aAU: 0.0485, periodDays: 11.186, radiusEarth: 1.07, hz: true, col: '#10b981' }
    ],
    desc: 'The closest known star to the Solar System at 4.246 light-years, hosting Earth-mass Proxima Centauri b in its liquid-water habitable zone.'
  },
  {
    id: '51Peg', name: '51 Pegasi (Helvetios & Dimidium)',
    subtitle: 'First Main-Sequence Exoplanet Host • Pegasus',
    category: 'exoplanet', typeLabel: 'G2V Star + Hot Jupiter (51 Peg b)',
    ra: 22.958, dec: 20.769, mag: 5.49, dist: '50.64 ± 0.05 ly', size: '0.0527 AU Orbit',
    color: '#fde047', accent: '#60a5fa',
    epoch: 'J2000.0 (ICRS)', provenance: 'NASA Exoplanet Archive / Hipparcos / Nobel 2019 Discovery',
    epistemicBadge: 'Measured Radial Velocity Orbit + Artistic Atmosphere',
    planets: [
      { name: 'b (Dimidium)', aAU: 0.0527, periodDays: 4.2308, radiusEarth: 13.5, hz: false, col: '#38bdf8' }
    ],
    desc: 'Sun-like G-type star hosting 51 Pegasi b (Dimidium), the prototype Hot Jupiter discovered in 1995 by Mayor and Queloz.'
  }
];

export const METEOR_SHOWERS_CATALOG = [
  { id: 'Orionids', name: 'Orionids (ORI) Radiant', ra: 6.33, dec: 15.6, zhr: 20, peak: 'Oct 21–Nov 7', parent: '1P/Halley', vKmS: 66 },
  { id: 'Taurids', name: 'Northern Taurids (NTA) Radiant', ra: 3.87, dec: 22.0, zhr: 5, peak: 'Nov 1–Nov 15', parent: '2P/Encke', vKmS: 29 },
  { id: 'Leonids', name: 'Leonids (LEO) Radiant', ra: 10.15, dec: 21.6, zhr: 15, peak: 'Nov 17–Nov 18', parent: '55P/Tempel-Tuttle', vKmS: 71 },
  { id: 'Geminids', name: 'Geminids (GEM) Radiant', ra: 7.47, dec: 32.2, zhr: 150, peak: 'Dec 13–Dec 14', parent: '3200 Phaethon', vKmS: 35 }
];

export const BLACK_HOLE_CATALOG = [
  {
    id: 'SgrA', name: 'Sagittarius A* (Galactic Center SMBH)',
    subtitle: 'Milky Way Supermassive Black Hole • Sagittarius',
    category: 'blackhole', typeLabel: 'Supermassive Black Hole (4.154 × 10⁶ M☉)',
    ra: 17.761, dec: -29.008, mag: 99.0, dist: '26,673 ± 42 ly', size: '51.8 μas Shadow',
    color: '#f97316', accent: '#fde047',
    epoch: 'J2000.0 (ICRS)', provenance: 'Event Horizon Telescope (EHT 2022) / GRAVITY Collaboration (VLT)',
    epistemicBadge: 'General-Relativistic Ray-Traced Accretion Visualization (EHT Calibrated)',
    desc: 'The 4.15-million-solar-mass supermassive black hole at the dynamical center of the Milky Way, directly imaged at 1.3 mm by the Event Horizon Telescope.'
  }
];
