# Stellarium 3D Desktop Observatory — PC & Laptop Website Edition

This package contains the dedicated **PC & Laptop Widescreen Web Edition** of **Stellarium 3D** with `highp` floating-point WebGL2 shaders, `2.0x` Retina/4K pixel ratio rendering, full keyboard shortcut matrix (`C`, `D`, `S`, `E`, `Z`, `G`, `A`, `K`, `N`, `M`, `L`, `I`, `Space`), and the Node.js backend server (`server.mjs`).

## Quick Start (Local PC / Laptop)

```bash
npm test
APIKEYS_IN_KEY="your_apikeys_in_key" node server.mjs
```
Then open `http://localhost:8080` in Chrome, Edge, Firefox, or Safari.

## Cloud Website Deployment (Render / Railway / Cloud Run / VPS)

- **Render**: Push this folder to GitHub and connect as a **Blueprint** (`render.yaml` is pre-configured).
- **Docker**:
  ```bash
  docker build -t stellarium-pc-web .
  docker run -d -p 8080:8080 -e APIKEYS_IN_KEY="your_key" stellarium-pc-web
  ```
- **Static Hosting (Netlify / Vercel / GitHub Pages / Cloudflare Pages)**:
  Upload the `public/` folder directly as your static publish directory.
